# Template: Data Research (Original Data Study)

**Template ID:** data-research
**Target Length:** 2,000-3,000 words
**Content Type:** Original data study with visualizations and actionable findings
**Primary Search Intent:** Informational ("study," "data," "statistics," "research," "benchmark")

## When to Use This Template

Use this template when:
- You have original data from surveys, experiments, tool analysis, or proprietary sources
- The study reveals findings that challenge assumptions or fill knowledge gaps
- You can present specific numbers, percentages, and comparisons
- Search queries include "statistics," "data," "study," "research," "benchmark," "how many"
- The data is unique enough that other sites will want to cite it (link-building potential)

Do NOT use this template for:
- Step-by-step instructions (use tutorial)
- Timely event commentary (use news-analysis)
- Reference/FAQ content (use faq-knowledge)
- Analysis based entirely on someone else's data (write a news-analysis instead)

**Value Note:** Original research can be useful when the methodology, evidence,
limitations, and results are transparent. The template itself carries no
ranking, backlink, or AI-citation guarantee.

---

## Title Format

```
[Study Title]: We Analyzed [N] [Things] - Key Findings
```

**Examples:**
- "AI Code Review Study: 10,000 Pull Request Findings"
- "Blog SEO Benchmark: Lessons From 500 Technical Blogs"
- "Developer Tooling Survey: What 2,000 Engineers Reported"

**Title Rules:**
- Include the specific sample size (N) - this is your credibility signal
- Name what was analyzed (pull requests, blogs, engineers, etc.)
- "We Analyzed/Studied/Surveyed" establishes original research
- Use a specific finding-led promise instead of generic reveal phrasing
- Keep under 70 characters for SERP display when possible

**Alternative Title Formats:**
- "[N] [Things] Analyzed: [Key Finding] ([Year] Study)"
- "The State of [Topic]: [N]-[Unit] Analysis"
- "[Topic] by the Numbers: Insights from [N] [Things]"

---

## Section-by-Section Structure

---

### Optional TL;DR Box

[ANSWER-FIRST] Summarize the findings most important to the reader. Include
numbers only where they are verified and necessary to understand the result.
Use as much space as completeness requires without padding.

```markdown
> **TL;DR:** We analyzed [N] [things] and found [Finding 1 with specific number].
> [Finding 2 with specific number]. Most surprisingly, [Finding 3 with specific number].
> [One-sentence implication for the reader].
```

**Rules:**
- State the primary result and practical implication clearly.
- Keep methodology or limitation context when omission would mislead.
- Do not force a number, surprise framing, or fixed finding count.
- Do not predict citation performance.

---

### Key Findings (200-300 words)

[ANSWER-FIRST] Present the supported headline findings as useful bullet points.
Each bullet should retain enough context to avoid misleading reuse; no fixed
count or citation prediction applies.

```markdown
## Key Findings

[ANSWER-FIRST] Our analysis of [N] [things] over [time period] revealed [N] key patterns.

[VISUAL: horizontal-bar chart showing the top 5-7 findings ranked by magnitude or importance]

1. **[Finding as a stat]:** [One sentence of context]. ([N]% of [sample])
2. **[Finding as a stat]:** [One sentence of context]. ([N]% of [sample])
3. **[Finding as a stat]:** [One sentence of context]. ([N]% of [sample])
4. **[Finding as a stat]:** [One sentence of context]. ([N]% of [sample])
5. **[Finding as a stat]:** [One sentence of context]. ([N]% of [sample])
6. **[Finding as a stat]:** [One sentence of context]. ([N]% of [sample])
7. **[Finding as a stat]:** [One sentence of context]. ([N]% of [sample])
```

**Rules:**
- Each bullet must be self-contained - citable without context
- Bold the data point, follow with one sentence of context
- Order by magnitude of impact or surprise, not by study order
- Include the visual chart immediately - readers want the overview first

---

### Methodology (200-300 words)

[ANSWER-FIRST] State exactly what you studied, how you studied it, and why the reader should trust the results.

```markdown
## Methodology

[ANSWER-FIRST] We analyzed [N] [things] collected from [source] between [start date] and [end date] using [analysis approach].

### Data Source

[Where the data came from, how it was collected, any selection criteria]

[INFO-GAIN: proprietary data source or unique collection method, documented
well enough for readers to evaluate and, where possible, reproduce the work]

### Sample

| Parameter | Value |
|-----------|-------|
| Sample size | [N] |
| Time period | [Start] to [End] |
| Source | [Where from] |
| Selection criteria | [How items were chosen] |
| Exclusions | [What was filtered out and why] |

### Analysis Approach

[1-2 paragraphs on how the data was analyzed - tools used, statistical methods, categorization approach]

### Limitations

- [Limitation 1]: [How it might affect findings]
- [Limitation 2]: [How it might affect findings]
- [Limitation 3]: [How it might affect findings]
```

**Rules:**
- Be transparent about limitations - this builds credibility
- The [INFO-GAIN] here is your unique data source or method
- Include enough detail that another researcher could evaluate (not necessarily reproduce) the study
- State exclusion criteria explicitly - readers will ask about selection bias

**Claim provenance:**

Give every statistic enough context and source detail to identify, verify, and
interpret it. Relevant details may include the publisher or report title,
publication date or study period, methodology and limitations, a stable URL,
and a retrieval date for changeable or undated material. No fixed citation form
is required. Drop unverifiable statistics and replace contradicted statistics
with verified alternatives. Reference:
`skills/blog/references/flow-alignment.md`.

---

### Finding Sections (300-400 words each, 4 findings)

Each finding uses an intent-matched H2. Questions and declarative findings are
both valid. Follow this structure for each:

```markdown
## [Finding as a Question]?

[ANSWER-FIRST] [State the finding as a specific statistic in the opening sentence. E.g., "78% of technical blogs that rank on page one use..."]

[2-3 paragraphs of detailed analysis:]

**The data:**

[VISUAL: chart appropriate to the finding - vary chart types across findings]

Suggested chart types per finding:
- Finding 1: Horizontal bar chart (comparison)
- Finding 2: Line chart (trend over time)
- Finding 3: Scatter plot (correlation)
- Finding 4: Stacked bar chart (composition)

**What this means:** [Interpretation of the data - what pattern does this reveal?]

**How this compares:** [Comparison to industry benchmarks, prior research, or conventional wisdom]

| This Study | Industry Benchmark | Difference |
|------------|--------------------|------------|
| [Our finding] | [Benchmark] | [Delta] |

[STAT: supporting data point from an external source that validates or contrasts with the finding]

**Practical implication:** [What should the reader do differently based on this finding?]

[INTERNAL-LINK: link to content that helps the reader act on this finding]
```

**Rules for finding sections:**
- Always open with the data point - never bury the lead
- Each finding must have its own visualization (vary chart types)
- Compare to a benchmark or prior research for context
- End with a practical implication - "so what?" for the reader
- Vary chart types across findings - don't use the same chart 4 times

---

### Surprises & Outliers (150-200 words)

[ANSWER-FIRST] Highlight findings that were unexpected or that challenge common assumptions. This section builds credibility - it shows you followed the data rather than confirming a narrative.

```markdown
## Surprises & Outliers

[ANSWER-FIRST] [N] findings contradicted our initial hypotheses or conventional wisdom.

**Surprise 1: [Counter-intuitive finding]**
We expected [expected result], but the data showed [actual result]. [Brief explanation of why this might be the case].

**Surprise 2: [Outlier or anomaly]**
[Description of the outlier and what it might indicate]

[INFO-GAIN: honest reflection on what was unexpected - this demonstrates intellectual rigor and makes the study more trustworthy]

> **What this tells us:** [1-2 sentence meta-insight about what the surprises reveal]
```

**Rules:**
- Include at least 2 surprises or outliers
- Be honest about what contradicted expectations
- Offer a hypothesis for the surprise, but flag it as speculation
- This section is often the most-shared part of a data study

---

### Limitations & Future Research (100-150 words)

[ANSWER-FIRST] Acknowledge what this study does not cover and what questions remain open.

```markdown
## Limitations & Future Research

[ANSWER-FIRST] This study has [N] key limitations that readers should consider when applying these findings.

**What this study doesn't cover:**
- [Limitation 1]: [Brief explanation]
- [Limitation 2]: [Brief explanation]

**Open questions for future research:**
- [Question 1]
- [Question 2]
- [Question 3]

[STAT: if applicable, reference a related study that addresses one of these gaps]
```

**Rules:**
- This section builds trust - be genuinely transparent
- Distinguish between limitations (things that weaken the findings) and scope boundaries (things outside the study's intent)
- Suggest specific future research directions (you may write those follow-ups)

---

### Implications & Recommendations (200-300 words)

[ANSWER-FIRST] Translate findings into specific, actionable recommendations for the reader.

```markdown
## Implications & Recommendations

[ANSWER-FIRST] Based on our findings, [audience] should [highest-priority recommendation].

### For [Audience Segment 1]:

1. **[Recommendation]:** Based on [Finding], [specific action]. [Expected impact].
2. **[Recommendation]:** Based on [Finding], [specific action]. [Expected impact].

### For [Audience Segment 2]:

1. **[Recommendation]:** Based on [Finding], [specific action]. [Expected impact].
2. **[Recommendation]:** Based on [Finding], [specific action]. [Expected impact].

[INTERNAL-LINK: link to tutorial or guide content that helps implement these recommendations]

[VISUAL: summary infographic or decision matrix if applicable]
```

**Rules:**
- Tie every recommendation directly to a specific finding (cite it)
- Be specific enough that the reader can take action
- Segment recommendations by audience if the study has broad appeal
- Include expected impact where possible

---

### Optional Reader Questions (count by reader need)

[ANSWER-FIRST] for each question. Anticipate questions about methodology, applicability, and specific findings.

```markdown
## Frequently Asked Questions

### How was this data collected?

[ANSWER-FIRST] [Direct answer in 1-2 sentences]. See our [Methodology](#methodology) section for full details.

### Does this apply to [specific audience/context]?

[ANSWER-FIRST] [Direct answer with scope clarification]. [Any caveats].

### How does this compare to [previous study/industry benchmark]?

[ANSWER-FIRST] [Direct comparison with specific numbers]. [Key difference explained].

[STAT: comparative data point]

### Can I cite this research?

[ANSWER-FIRST] Yes. Please cite as: [Your name/org], "[Study Title]," [Publication name], [Date]. [Link to this page].

### When will this data be updated?

[ANSWER-FIRST] [Direct answer with timeline or conditions for update].
```

**FAQ Rules:**
- Include a methodology question (most common reader concern)
- Include a scope/applicability question
- Include a citation question (encourage backlinks)
- Answers should be concise and complete; Google has no required answer length

---

### Data Appendix

```markdown
## Data Appendix

### Summary Data Table

| [Category] | [Metric 1] | [Metric 2] | [Metric 3] |
|------------|-------------|-------------|-------------|
| [Row 1] | [Value] | [Value] | [Value] |
| [Row 2] | [Value] | [Value] | [Value] |
| [Row 3] | [Value] | [Value] | [Value] |
| ... | ... | ... | ... |

**Download raw data:** [Link to CSV/spreadsheet if applicable]

**Citation format:**
> [Your name/org]. "[Study Title]." [Publication name], [Date]. [URL].
```

**Rules:**
- Include a summary data table at minimum
- Offer raw data download if possible (increases backlink potential)
- Provide a citation format (makes it easy for others to reference)
- Include the date prominently (data studies have a shelf life)

---

## Content Checklist

Before publishing, verify:

- [ ] Title includes specific sample size (N)
- [ ] Optional TL;DR accurately summarizes the result and material limitations
- [ ] Key Findings contains the supported findings needed by the reader
- [ ] Methodology section includes sample size, time period, source, and limitations
- [ ] At least 1 [INFO-GAIN] in methodology (proprietary data/method)
- [ ] 4 Finding sections, each with a unique chart type
- [ ] Every finding opens with a specific data point (answer-first)
- [ ] Every finding includes a benchmark comparison
- [ ] Every finding ends with a practical implication
- [ ] At least 4 [VISUAL] markers with varied chart types
- [ ] External statistics are included only when material and verified; no
      minimum applies
- [ ] Surprises section includes 2+ counter-intuitive findings
- [ ] Limitations are honestly stated
- [ ] Recommendations are tied to specific findings
- [ ] At least 3 [INTERNAL-LINK] zones
- [ ] FAQ includes methodology and citation questions
- [ ] Data appendix with summary table and citation format
- [ ] All data verified and calculations double-checked
