# Argument outline capability

**Input:** brief, source material or interview answers, intended reader, supplied
structure if any, and voice.
**Output:** thesis/reader takeaway, opening approach, and section plan with purpose,
evidence needs, boundaries, and transitions.

Design one argument that develops across the article. Give every section a unique
job; merge overlap and keep examples from being repeatedly introduced. Choose
sections to fit the substance rather than a word-per-section quota. Source briefs
are material to select/reframe, not headings or ordering to copy automatically.
Preserve a supplied outline when expansion rather than restructuring was requested.

A useful section plan names its title, unique contribution, relation to the prior
section, evidence/examples, and what belongs elsewhere. Mark unsupported areas
as research needs; do not invent supporting facts. Opening and first section
should progress rather than repeat each other. Save the outline/checkpoint via
[workspace](../workspace.md); outline-only mode stops here.

The [BlogForge outline prompt](../blogforge/generate/prompts/outline.j2) supplies
conditional detail. Its JSON/Jinja contract is optional here. Templates from
[blog-write](blog-write.md) can help when the article type benefits from them.
